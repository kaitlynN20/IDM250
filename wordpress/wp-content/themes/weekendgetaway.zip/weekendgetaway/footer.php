<footer class="page-footer font-small blue pt-2">
    <div class="contact-box">
        <p></p>
    </div>
        <div class="footer-copyright text-center py-3">© 2018 Copyright:
        <a href="https://mdbootstrap.com/bootstrap-tutorial/"> MDBootstrap.com</a>
      </div>
</footer>
<?php wp_footer();?>
</body>
</html>